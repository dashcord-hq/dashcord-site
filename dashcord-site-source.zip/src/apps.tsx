import React from 'react';
// @ts-ignore vendored qrcode-generator (MIT)
import qrcode from './qrcode.js';
import { ANDROID_URL, IOS_URL } from './config';

function QR({ url, label }: { url: string; label: string }) {
  const q = (qrcode as any)(0, 'M');
  q.addData(url); q.make();
  const n: number = q.getModuleCount();
  const cells: string[] = [];
  for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) if (q.isDark(r, c)) cells.push(`M${c} ${r}h1v1h-1z`);
  return (
    <svg className="dc-qr" viewBox={`-2 -2 ${n + 4} ${n + 4}`} role="img" aria-label={label} shapeRendering="crispEdges">
      <rect x="-2" y="-2" width={n + 4} height={n + 4} fill="#fff" /><path d={cells.join('')} fill="#0b1b3f" />
    </svg>
  );
}
const Soon = () => (
  <div className="dc-qr dc-qr-soon" aria-hidden="true">
    <svg viewBox="0 0 29 29" shapeRendering="crispEdges">
      {[[0, 0], [22, 0], [0, 22]].map(([x, y]) => <g key={x + '-' + y}><rect x={x} y={y} width="7" height="7" fill="#0b1b3f" /><rect x={x + 1} y={y + 1} width="5" height="5" fill="#fff" /><rect x={x + 2} y={y + 2} width="3" height="3" fill="#0b1b3f" /></g>)}
      {Array.from({ length: 60 }, (_, i) => { const x = 9 + ((i * 7) % 13), y = 1 + ((i * 11) % 27); return <rect key={i} x={x} y={y} width="1.6" height="1.6" fill="#c9d6f5" />; })}
    </svg>
    <span>قريبًا</span>
  </div>
);
const Play = () => <svg viewBox="0 0 24 24" width="26" height="26" aria-hidden="true"><path d="M4 2.5v19l10-9.500z" fill="#00d1ff" /><path d="M4 2.500l12 7-2 2.500z" fill="#00e676" /><path d="M4 21.500l12-7-2-2.500z" fill="#ff3d5a" /><path d="M16 9.500l4 2.500-4 2.500-2-2.500z" fill="#ffc400" /></svg>;
const Apple = () => <svg viewBox="0 0 24 24" width="26" height="26" fill="currentColor" aria-hidden="true"><path d="M16.400 12.600c0-2.300 1.900-3.400 2-3.500-1.100-1.600-2.800-1.800-3.400-1.800-1.400-.1-2.800.9-3.500.9s-1.800-.8-3-.8C6.900 7.400 5.400 8.300 4.600 9.800c-1.700 2.900-.4 7.200 1.200 9.600.8 1.100 1.700 2.400 2.900 2.400 1.200 0 1.600-.8 3-.8s1.800.8 3 .7c1.300 0 2.100-1.200 2.800-2.300.9-1.300 1.200-2.600 1.300-2.600-.1 0-2.400-.9-2.400-3.700zM14.200 5.700c.6-.8 1.100-1.800.9-2.900-.9 0-2 .6-2.700 1.400-.6.700-1.100 1.800-1 2.800 1 .1 2-.5 2.800-1.300z" /></svg>;

function Store({ kind, url }: { kind: 'android' | 'ios'; url: string }) {
  const name = kind === 'android' ? 'Google Play' : 'App Store';
  const sub = kind === 'android' ? 'GET IT ON' : 'Download on the';
  const inner = <><span className="dc-store-ic">{kind === 'android' ? <Play /> : <Apple />}</span><span className="dc-store-t"><small>{sub}</small><b>{name}</b></span>{!url && <em>قريبًا</em>}</>;
  return (
    <div className="dc-store">
      {url ? <a className="dc-store-b" href={url} target="_blank" rel="noopener noreferrer">{inner}</a> : <div className="dc-store-b is-soon">{inner}</div>}
      {url ? <QR url={url} label={'رمز QR لتحميل التطبيق من ' + name} /> : <Soon />}
      <p>{kind === 'android' ? 'تطبيق Android' : 'تطبيق iOS'}</p>
    </div>
  );
}
export const AppSection = () => (
  <section className="dc-sec dc-apps-sec">
    <div className="dc-apps">
      <div className="dc-apps-t">
        <span className="dc-pill">تطبيق الجوال</span>
        <h2>تطبيق DashCord على <em>Android وiOS</em></h2>
        <p>{ANDROID_URL || IOS_URL ? 'حمّل تطبيق DashCord من المتجر، أو امسح الرمز بكاميرا جوالك.' : 'تطبيقا Android وiOS قيد الرفع على المتاجر حاليًا. سيظهر هنا رمز QR لكل متجر فور إتاحة التطبيق.'}</p>
      </div>
      <div className="dc-apps-s"><Store kind="android" url={ANDROID_URL} /><Store kind="ios" url={IOS_URL} /></div>
    </div>
  </section>
);
