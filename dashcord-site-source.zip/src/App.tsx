import React, { useState } from 'react';
import * as D from './data';
import hero from './img/hero.jpg'; import fleet from './img/fleet.jpg'; import ops from './img/ops.jpg';
import fin from './img/fin.jpg'; import ana from './img/ana.jpg'; import sup from './img/sup.jpg'; import cta from './img/cta.jpg';
import th0 from './img/th0.jpg'; import th1 from './img/th1.jpg'; import th2 from './img/th2.jpg'; import th3 from './img/th3.jpg'; import th4 from './img/th4.jpg';
import sec0 from './img/sec0.jpg'; import sec1 from './img/sec1.jpg'; import sec2 from './img/sec2.jpg'; import sec3 from './img/sec3.jpg'; import sec4 from './img/sec4.jpg';
import { Icon } from './icons';
import { WaWidget } from './WaWidget';
import { CONTACT_PHONE } from './config';
import { DemoForm } from './DemoForm';
import logo from './img/logo.png'; import logow from './img/logow.png';

const img: Record<string, string> = { hero, fleet, ops, fin, ana, sup, cta, th0, th1, th2, th3, th4 };
const secImgs = [sec0, sec1, sec2, sec3, sec4];
const go = (id: string) => document.getElementById('dc-' + id)?.scrollIntoView({ behavior: 'smooth', block: 'start' });

function SocialIcon({ k }: { k: string }) {
  const p: Record<string, string> = {
    instagram: 'M7 2h10a5 5 0 015 5v10a5 5 0 01-5 5H7a5 5 0 01-5-5V7a5 5 0 015-5zm5 5.5A4.5 4.5 0 1016.5 12 4.5 4.5 0 0012 7.5zm0 2A2.5 2.5 0 119.5 12 2.5 2.5 0 0112 9.5zM17.3 5.8a1.1 1.1 0 101.1 1.1 1.1 1.1 0 00-1.1-1.1z',
    facebook: 'M13.5 22v-8.2h2.8l.5-3.3h-3.3V8.4c0-.9.4-1.7 1.8-1.7H17V3.8A19 19 0 0014.6 3.6c-2.5 0-4.2 1.5-4.2 4.3v2.6H7.6v3.3h2.8V22z',
    whatsapp: 'M12 2a10 10 0 00-8.6 15L2 22l5.2-1.4A10 10 0 1012 2zm0 18.2a8.2 8.2 0 01-4.2-1.2l-.3-.2-3 .8.8-2.9-.2-.3A8.2 8.2 0 1112 20.200zm4.5-6.100c-.2-.1-1.500-.7-1.700-.8s-.4-.1-.6.100-.6.8-.8 1-.3.2-.6.1a6.700 6.700 0 01-3.300-2.900c-.2-.4.200-.4.700-1.300a.5.500 0 000-.5l-.8-1.800c-.2-.5-.4-.4-.6-.4h-.5a1 1 0 00-.7.300 3 3 0 00-.9 2.200 5.200 5.200 0 001.100 2.800 11.900 11.900 0 004.600 4c1.700.7 2.300.8 3.200.7a2.700 2.700 0 001.800-1.300 2.200 2.200 0 00.2-1.300c-.1-.1-.3-.2-.6-.3z',
    tiktok: 'M16.6 2h-3.100v13.400a2.800 2.800 0 11-2.800-2.800c.3 0 .6 0 .8.1V9.500a6 6 0 105.100 5.900V8.800a7.300 7.300 0 004.200 1.300V7a4.300 4.300 0 01-4.200-5z',
    x: 'M18.200 2.300h3.300l-7.200 8.300L22.800 21.700h-6.600l-5.200-6.800-5.900 6.800H1.800l7.700-8.800L1.500 2.300h6.800l4.700 6.200zm-1.200 17.400h1.800L7.100 4.200H5.100z',
    youtube: 'M21.600 7.200a2.700 2.700 0 00-1.900-1.900C18 4.800 12 4.800 12 4.800s-6 0-7.700.5A2.700 2.700 0 002.400 7.200 28 28 0 002 12a28 28 0 00.4 4.800 2.700 2.700 0 001.900 1.900c1.700.5 7.700.5 7.700.5s6 0 7.700-.5a2.700 2.700 0 001.900-1.900A28 28 0 0022 12a28 28 0 00-.4-4.800zM10 15V9l5.200 3z',
    linkedin: 'M4.300 8.800h3.400V20H4.300zM6 3.500a2 2 0 11-2 2 2 2 0 012-2zm4 5.300h3.200v1.500a3.500 3.500 0 013.200-1.800c3.400 0 4 2.200 4 5.100V20h-3.400v-5.600c0-1.300 0-3-1.800-3s-2.100 1.400-2.100 2.900V20H10z',
  };
  return <svg viewBox="0 0 24 24" width="22" height="22" fill="currentColor" aria-hidden="true"><path d={p[k]} /></svg>;
}

const Ico = ({ c }: { c: string }) => <span className="dc-ico" aria-hidden="true"><Icon e={c} /></span>;
const Head = ({ badge, a, hl, b, sub }: { badge: string; a?: string; hl: string; b?: string; sub: string }) => (
  <div className="dc-head">
    <span className="dc-badge">{badge}</span>
    <h2>{a} <em>{hl}</em> {b}</h2>
    <p>{sub}</p>
  </div>
);
const Strip = ({ items }: { items: string[][] }) => (
  <div className="dc-strip">{items.map(([i, t, d]) => <div key={t} className="dc-strip-i"><Ico c={i} /><div><b>{t}</b><span>{d}</span></div></div>)}</div>
);
const Items = ({ items }: { items: string[][] }) => (
  <div className="dc-items">{items.map(([i, t, d]) => <div key={t} className="dc-item"><Ico c={i} /><div><b>{t}</b><p>{d}</p></div></div>)}</div>
);
const Stats = ({ items }: { items: string[][] }) => (
  <div className="dc-strip dc-stats">{items.map(([i, v, l]) => <div key={l} className="dc-strip-i"><Ico c={i} /><div><b className="dc-big">{v}</b><span>{l}</span></div></div>)}</div>
);

export function App() {
  const [tab, setTab] = useState(0);
  const [menu, setMenu] = useState(false);
  const [email, setEmail] = useState('');
  const [subbed, setSubbed] = useState(false);
  const s = D.screens[tab];
  return (
    <div className="dc" dir="rtl" id="dc-top">
      <header className="dc-nav">
        <img className="dc-logo" src={logo} alt="DashCord" />
        <nav className={menu ? 'is-open' : ''}>
          {D.nav.map(([t, id]) => <button type="button" key={id} className={id === 'top' ? 'on' : ''} onClick={() => { setMenu(false); go(id === 'top' ? 'top' : id); }}>{t}</button>)}
        </nav>
        <div className="dc-nav-cta">
          <button type="button" className="dc-btn dc-btn-ghost dc-hide-s">تسجيل الدخول</button>
          <button type="button" className="dc-btn dc-btn-primary" onClick={() => go('demo')}>احجز عرضًا تجريبيًا</button>
          <button type="button" className="dc-burger" aria-label="القائمة" onClick={() => setMenu(!menu)}><svg viewBox="0 0 24 24" width="22" height="22" stroke="#0b1b3f" strokeWidth="2" strokeLinecap="round"><path d="M4 7h16M4 12h16M4 17h16" /></svg></button>
        </div>
      </header>

      <section className="dc-hero">
        <div className="dc-hero-text">
          <span className="dc-pill">● منصة موحدة • إدارة أسهل • قرارات أدق</span>
          <h1>منصة متكاملة لإدارة <br />عملياتك <em>بكفاءة عالية</em></h1>
          <p>DashCord تساعد الشركات على إدارة المركبات والموظفين والمناديب والتسويات والتقارير من خلال نظام واحد متكامل يمنحك رؤية واضحة تحسن الأداء وتزيد من الإنتاجية.</p>
          <div className="dc-row">
            <button type="button" className="dc-btn dc-btn-primary dc-lg" onClick={() => go('demo')}>احجز عرضًا تجريبيًا ←</button>
            <button type="button" className="dc-btn dc-btn-ghost dc-lg" onClick={() => go('screens')}>▶ شاهد المنصة</button>
          </div>
          <div className="dc-chips">{D.heroChips.map(([i, t]) => <span key={t}><Ico c={i} />{t}</span>)}</div>
          <div className="dc-hstats">{D.heroStats.map(([v, l]) => <div key={l}><b>{v}</b><span>{l}</span></div>)}</div>
        </div>
        <img className="dc-shot" src={hero} alt="لوحة تحكم DashCord" />
      </section>

      <section className="dc-sec" id="dc-fleet">
        <Head badge="إدارة الأساطيل والمركبات" hl="مكان واحد" a="إدارة المركبات من" sub="ملف مركبة متكامل، تتبع الصيانة والتأمين، إدارة التفويضات والاستلام والتسليم، وكل ما تحتاجه لضمان تشغيل آمن وفعال لأسطولك." />
        <div className="dc-two">
          <div><h3>كل ما يخص مركباتك <em>في نظام متكامل</em></h3><Items items={D.fleetItems} /></div>
          <img className="dc-shot" src={fleet} alt="إدارة المركبات" />
        </div>
        <Stats items={D.fleetStats} />
      </section>

      <section className="dc-sec" id="dc-ops">
        <Head badge="إدارة التشغيل" a="إدارة الموظفين والمناديب" hl="من مكان واحد" sub="تحكم شامل في جميع عمليات التشغيل اليومية، من إدارة الموظفين والمناديب وملفاتهم، إلى الحضور والانصراف، الشيفتات، الأداء والتقييم." />
        <div className="dc-two dc-flip">
          <Items items={D.opsItems} />
          <img className="dc-shot" src={ops} alt="إدارة التشغيل" />
        </div>
        <Strip items={D.opsStrip} />
      </section>

      <section className="dc-sec" id="dc-fin">
        <Head badge="التسويات المالية" a="تحكم كامل في العمليات" hl="المالية" sub="إدارة جميع التسويات والمستحقات والمدفوعات بدقة وشفافية تامة، مع تقارير تفصيلية تساعدك على اتخاذ قرارات مالية أفضل." />
        <div className="dc-two dc-flip">
          <Items items={D.finItems} />
          <img className="dc-shot" src={fin} alt="التسويات المالية" />
        </div>
        <Stats items={D.finStats} />
      </section>

      <section className="dc-sec" id="dc-ana">
        <Head badge="التقارير التحليلية" a="حوّل بياناتك إلى" hl="قرارات ذكية" sub="لوحات تحكم وتقارير تفاعلية تمنحك رؤية واضحة لأداء عملياتك في الوقت الحقيقي، لمساعدتك على اتخاذ قرارات أسرع وأكثر دقة." />
        <div className="dc-two">
          <div><h3>تقارير شاملة تغطي <em>كل جوانب عملك</em></h3><Items items={D.anaItems} /><button type="button" className="dc-btn dc-btn-ghost">← عرض جميع التقارير</button></div>
          <img className="dc-shot" src={ana} alt="التقارير التحليلية" />
        </div>
        <Strip items={D.anaStrip} />
      </section>

      <section className="dc-sec" id="dc-sup">
        <Head badge="الدعم" a="دعم فني" hl="ومتابعة مستمرة" sub="فريق دعم متخصص جاهز لمساعدتك في أي وقت. نقدم لك تجربة دعم سريعة وفعالة لضمان استمرار أعمالك بدون توقف." />
        <div className="dc-two dc-flip">
          <Items items={D.supItems} />
          <img className="dc-shot" src={sup} alt="مركز الدعم" />
        </div>
        <Strip items={D.supStrip} />
      </section>

      <section className="dc-sec dc-tint" id="dc-screens">
        <Head badge="شاشات النظام" a="واجهة واحدة،" hl="كل ما تحتاجه" sub="تصميم بسيط وتجربة مستخدم سلسة تساعد على إدارة عملياتك بكفاءة من أي مكان وفي أي وقت." />
        <div className="dc-tabs" role="tablist">{D.screens.map(([t], i) => <button type="button" role="tab" aria-selected={tab === i} key={t} className={tab === i ? 'on' : ''} onClick={() => setTab(i)}>{t}</button>)}</div>
        <div className="dc-screen"><img className="dc-shot" src={img[s[2]]} alt={s[0]} /><div><h3>{s[0]}</h3><p>{s[1]}</p></div></div>
        <div className="dc-thumbs">{D.screens.map(([t, d, , th], i) => <button type="button" key={t} className={tab === i ? 'on' : ''} onClick={() => setTab(i)}><img src={img[th]} alt="" /><b>{t}</b><span>{d}</span></button>)}</div>
        <Strip items={D.screenFeatures} />
      </section>

      <section className="dc-sec">
        <Head badge="مصمم لمختلف القطاعات" a="مصمم للشركات في" hl="مختلف القطاعات" sub="DashCord تقدم حلولاً مرنة وقابلة للتخصيص تناسب احتياجات كل قطاع، لمساعدتك على إدارة عملياتك بكفاءة أعلى وتحقيق نتائج أفضل." />
        <div className="dc-cards5">{D.sectors.map(([i, t, d, l], n) => (
          <article key={t} className="dc-card"><div className="dc-card-img"><img src={secImgs[n]} alt={t} /><Ico c={i} /></div><h4>{t}</h4><p>{d}</p><ul>{(l as string[]).map((x) => <li key={x}>{x}</li>)}</ul><a className="dc-more">← اعرف المزيد</a></article>
        ))}</div>
        <p className="dc-note">سواء كنت شركة صغيرة أو مؤسسة كبيرة، DashCord يوفر لك الأدوات التي تحتاجها لإدارة عملياتك بكفاءة واحترافية.</p>
      </section>

      <section className="dc-sec">
        <Head badge="أرقام وإحصائيات" a="أداء موثوق و" hl="أرقام تتحدث" b="عن نجاحنا" sub="نفخر بثقة آلاف الشركات التي تعتمد على DashCord لإدارة عملياتها اليومية وتحقيق أعلى مستويات الكفاءة والإنتاجية." />
        <div className="dc-cards5">{D.numbers.map(([i, v, t, d, c]) => (
          <article key={t} className="dc-num"><Ico c={i} /><b style={{ color: c }}>{v}</b><h4>{t}</h4><p>{d}</p><span className="dc-grow" style={{ color: c }}>متزايد يوميًا</span></article>
        ))}</div>
        <p className="dc-note">نلتزم بتوفير منصة آمنة، سريعة وموثوقة تساعدك على اتخاذ أفضل القرارات وتحقيق نمو مستدام لأعمالك.</p>
      </section>

      <section className="dc-sec dc-tint">
        <Head badge="لماذا DashCord؟" a="كل ما تحتاجه في" hl="منصة واحدة" sub="DashCord تجمع كل الأدوات التي تحتاجها لإدارة عملياتك اليومية في منصة متكاملة مصممة لزيادة الكفاءة وتقليل التكاليف وتحقيق نمو مستدام." />
        <div className="dc-cards4">{D.why.map(([i, t, d, c]) => (
          <article key={t} className="dc-why"><Ico c={i} /><h4>{t}</h4><p>{d}</p><a className="dc-more" style={{ color: c }}>← اعرف المزيد</a></article>
        ))}</div>
        <div className="dc-promise"><div><b>DashCord ليست مجرد نظام، بل شريكك في نجاح عملياتك.</b><span>نساعدك على التحكم الكامل، وتقليل التكاليف، وزيادة الإنتاجية، وتحقيق أهدافك بثقة.</span></div><div className="dc-pstats"><div><b>+60%</b><span>زيادة في الإنتاجية</span></div><div><b>-40%</b><span>توفير في التكاليف</span></div><div><b>+98%</b><span>تحسن في الكفاءة</span></div></div></div>
      </section>

      <section className="dc-sec" id="dc-cta">
        <div className="dc-cta">
          <div className="dc-cta-text">
            <span className="dc-pill">ابدأ رحلتك الآن</span>
            <h2>جاهز للانطلاق مع <em>DashCord</em>؟</h2>
            <p>انضم إلى آلاف الشركات التي تدير عملياتها بكفاءة أعلى وتحقق نتائج أفضل كل يوم.</p>
            <div className="dc-row">
              <button type="button" className="dc-btn dc-btn-primary dc-lg dc-stack" onClick={() => go('demo')}><b>احجز عرضًا تجريبيًا ←</b><small>تجربة مجانية - بدون بطاقة بنكية</small></button>
              <a className="dc-btn dc-btn-ghost dc-lg dc-stack" href="mailto:info@dash-cord.com"><b>تواصل معنا</b><small>تحدث مع فريق المبيعات</small></a>
            </div>
            <p className="dc-small">آمن 100% • بياناتك محمية • إلغاء في أي وقت</p>
          </div>
          <img className="dc-shot dc-cta-img" src={cta} alt="DashCord على الكمبيوتر والجوال" />
        </div>
        <Strip items={D.ctaStrip} />
      </section>

      <DemoForm />

      <footer className="dc-foot">
        <div className="dc-foot-grid">
          <div className="dc-foot-brand">
            <img src={logow} alt="DashCord" />
            <p>منصة تشغيل متكاملة تساعد الشركات على إدارة الموظفين، المركبات، العمليات، التسويات، التقارير والتنبيهات من خلال نظام واحد ذكي وسهل الاستخدام.</p>
            <h5>تواصل معنا</h5>
            <a href="mailto:info@dash-cord.com">info@dash-cord.com</a>
            {CONTACT_PHONE && <a href={`tel:${CONTACT_PHONE.replace(/\s/g, '')}`} dir="ltr" style={{ alignSelf: 'flex-start' }}>{CONTACT_PHONE}</a>}
            <span>www.dash-cord.com</span>
            <span>المملكة العربية السعودية</span>
          </div>
          {D.footerCols.map(([t, l]) => <div key={t as string}><h5>{t as string}</h5>{(l as string[]).map((x) => <span key={x}>{x}</span>)}</div>)}
        </div>
        <div className="dc-foot-bar">
          <div className="dc-sub">
            <div><b>اشترك في نشرتنا البريدية</b><span>احصل على آخر التحديثات والنصائح والعروض مباشرة إلى بريدك الإلكتروني.</span></div>
            {subbed ? <b className="dc-ok">شكرًا لاشتراكك</b> : <div className="dc-subform"><input type="email" inputMode="email" placeholder="ادخل بريدك الإلكتروني" value={email} onChange={(e) => setEmail(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter' && /\S+@\S+/.test(email)) setSubbed(true); }} /><button type="button" className="dc-btn dc-btn-primary" onClick={() => /\S+@\S+/.test(email) && setSubbed(true)}>اشترك الآن</button></div>}
          </div>
          <div className="dc-soc"><h5>تابعنا على</h5><div>{D.socials.map(([n, u, k]) => <a key={k} href={u} target="_blank" rel="noopener noreferrer" aria-label={n} title={n}><SocialIcon k={k} /></a>)}</div></div>
        </div>
        <p className="dc-copy">© 2026 DashCord. جميع الحقوق محفوظة.</p>
      </footer>
      <WaWidget />
    </div>
  );
}
