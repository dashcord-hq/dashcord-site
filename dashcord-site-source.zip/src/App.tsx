import React, { useEffect, useState } from 'react';
import * as D from './data';
import logo from './img/logo.png'; import logow from './img/logow.png';
import { WaWidget } from './WaWidget';
import { CONTACT_PHONE } from './config';
import { SocialIcon, nav } from './sections';
import { useMotion } from './motion';
import { Home, Features, Vehicles, Operations, Settlements, Reports, Sectors, Pricing, About, Support, Faq, Contact, Demo, Legal, legalLinks } from './pages';

const pages: Record<string, [React.ComponentType, string, string]> = {
  '': [Home, 'DashCord | منصة متكاملة لإدارة عملياتك', 'home'],
  features: [Features, 'المميزات', 'features'],
  vehicles: [Vehicles, 'إدارة المركبات والأساطيل', 'features'],
  operations: [Operations, 'إدارة التشغيل', 'features'],
  settlements: [Settlements, 'التسويات المالية', 'features'],
  reports: [Reports, 'التقارير التحليلية', 'features'],
  sectors: [Sectors, 'القطاعات', 'sectors'],
  pricing: [Pricing, 'الأسعار', 'pricing'],
  about: [About, 'من نحن', 'about'],
  support: [Support, 'الدعم', 'support'],
  faq: [Faq, 'الأسئلة الشائعة', 'faq'],
  contact: [Contact, 'تواصل معنا', 'contact'],
  demo: [Demo, 'احجز عرضًا تجريبيًا', 'demo'],
};
const menu: [string, string][] = [['الرئيسية', 'home'], ['المميزات', 'features'], ['القطاعات', 'sectors'], ['الأسعار', 'pricing'], ['من نحن', 'about'], ['الأسئلة الشائعة', 'faq'], ['تواصل معنا', 'contact']];
const toPath = (k: string) => (k === 'home' ? '' : k);

function useRoute() {
  const get = () => { let h = window.location.hash; try { h = decodeURIComponent(h); } catch (e) { /* keep raw */ } return (h.replace(/^#\/?/, '').split('?')[0] || '').replace(/\/$/, ''); };
  const [r, setR] = useState(get());
  useEffect(() => {
    const f = () => setR(get());
    window.addEventListener('hashchange', f);
    return () => window.removeEventListener('hashchange', f);
  }, []);
  return r;
}

export function App() {
  const route = useRoute();
  const [open, setOpen] = useState(false);
  const [stuck, setStuck] = useState(false);
  const [prog, setProg] = useState(0);
  const [email, setEmail] = useState('');
  const [subbed, setSubbed] = useState(false);
  const legalSlugs = legalLinks.map(([k]) => k);
  const isLegal = legalSlugs.includes(route);
  const entry = pages[route];
  const known = !!entry || isLegal;
  const Page = entry ? entry[0] : Home;
  const active = isLegal ? '' : entry ? entry[2] : 'home';
  const title = isLegal ? (legalLinks.find(([k]) => k === route) as string[])[1] : entry ? entry[1] : 'DashCord';

  useEffect(() => {
    window.scrollTo(0, 0); setOpen(false);
    document.title = route === '' ? entry[1] : title + ' | DashCord';
  }, [route]);
  useEffect(() => {
    const f = () => {
      setStuck(window.scrollY > 10);
      const h = document.documentElement.scrollHeight - window.innerHeight;
      setProg(h > 0 ? Math.min(1, window.scrollY / h) : 0);
    };
    window.addEventListener('scroll', f, { passive: true }); f();
    return () => window.removeEventListener('scroll', f);
  }, []);
  useMotion(route);

  return (
    <div className="dc" dir="rtl" id="dc-top">
      <div className="dc-prog" style={{ transform: `scaleX(${prog})` }} />
      <header className={'dc-nav' + (stuck ? ' stuck' : '')}>
        <a href="#/" aria-label="DashCord"><img className="dc-logo" src={logo} alt="DashCord" /></a>
        <nav className={open ? 'is-open' : ''}>
          {menu.map(([t, k]) => <a key={k} href={'#/' + toPath(k)} className={active === k ? 'on' : ''}>{t}</a>)}
        </nav>
        <div className="dc-nav-cta">
          <a className="dc-btn dc-btn-ghost dc-hide-s" href="https://dashboard.dash-cord.com/#/login" target="_blank" rel="noopener noreferrer">تسجيل الدخول</a>
          <button type="button" className="dc-btn dc-btn-primary" onClick={() => nav('demo')}>احجز عرضًا تجريبيًا</button>
          <button type="button" className="dc-burger" aria-label="القائمة" onClick={() => setOpen(!open)}><svg viewBox="0 0 24 24" width="22" height="22" stroke="#0b1b3f" strokeWidth="2" strokeLinecap="round"><path d="M4 7h16M4 12h16M4 17h16" /></svg></button>
        </div>
      </header>

      <main key={route} className="dc-page">
        {known ? (isLegal ? <Legal slug={route} /> : <Page />) : <section className="dc-sec" style={{ textAlign: 'center' }}><h1>الصفحة غير موجودة</h1><p><a className="dc-btn dc-btn-primary" href="#/">العودة للرئيسية</a></p></section>}
      </main>

      <footer className="dc-foot">
        <div className="dc-foot-grid">
          <div className="dc-foot-brand">
            <img src={logow} alt="DashCord" />
            <p>منصة تشغيل متكاملة تساعد الشركات على إدارة الموظفين، المركبات، العمليات، التسويات، التقارير والتنبيهات من خلال نظام واحد ذكي وسهل الاستخدام.</p>
            <h5>تواصل معنا</h5>
            <a href="mailto:info@dash-cord.com">info@dash-cord.com</a>
            {CONTACT_PHONE && <a href={`tel:${String(CONTACT_PHONE).replace(/\s/g, '')}`} dir="ltr" style={{ alignSelf: 'flex-start' }}>{CONTACT_PHONE}</a>}
            <span>www.dash-cord.com</span>
            <span>المملكة العربية السعودية</span>
          </div>
          <div><h5>روابط سريعة</h5>{[['الرئيسية', ''], ['المميزات', 'features'], ['الأسعار', 'pricing'], ['من نحن', 'about'], ['الأسئلة الشائعة', 'faq'], ['تواصل معنا', 'contact']].map(([t, k]) => <a key={k} href={'#/' + k}>{t}</a>)}</div>
          <div><h5>الحلول</h5>{[['إدارة المركبات والأساطيل', 'vehicles'], ['إدارة التشغيل', 'operations'], ['التسويات المالية', 'settlements'], ['التقارير التحليلية', 'reports'], ['الدعم', 'support']].map(([t, k]) => <a key={k} href={'#/' + k}>{t}</a>)}</div>
          <div><h5>القطاعات</h5><a href="#/sectors">القطاعات التي نخدمها</a><a href="#/demo">احجز عرضًا تجريبيًا</a></div>
          <div><h5>قانوني</h5>{legalLinks.map(([k, t]) => <a key={k} href={'#/' + k}>{t}</a>)}</div>
        </div>
        <div className="dc-foot-bar">
          <div className="dc-sub">
            <div><b>اشترك في نشرتنا البريدية</b><span>احصل على آخر التحديثات والنصائح والعروض مباشرة إلى بريدك الإلكتروني.</span></div>
            {subbed ? <b className="dc-ok">شكرًا لاشتراكك</b> : <div className="dc-subform"><input type="email" inputMode="email" placeholder="ادخل بريدك الإلكتروني" value={email} onChange={(e) => setEmail(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter' && /\S+@\S+/.test(email)) setSubbed(true); }} /><button type="button" className="dc-btn dc-btn-primary" onClick={() => /\S+@\S+/.test(email) && setSubbed(true)}>اشترك الآن</button></div>}
          </div>
          <div className="dc-soc"><h5>تابعنا على</h5><div>{D.socials.map(([n, u, k]) => <a key={k} href={u} target="_blank" rel="noopener noreferrer" aria-label={n} title={n}><SocialIcon k={k} /></a>)}</div></div>
        </div>
        <p className="dc-copy">© 2026 DashCord. جميع الحقوق محفوظة. · <a href="#/privacy">سياسة الخصوصية</a></p>
      </footer>
      <WaWidget />
    </div>
  );
}
