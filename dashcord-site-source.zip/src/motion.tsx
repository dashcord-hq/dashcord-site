import React, { useEffect, useRef, useState } from 'react';

/* Scroll-triggered reveal + count-up. Call once per route render. */
const REVEAL = '.dc-head,.dc-blk-h,.dc-item,.dc-card,.dc-why,.dc-num,.dc-strip-i,.dc-shot,.dc-thumbs button,.dc-promise,.dc-cta,.dc-ctabar,.dc-faq-i,.dc-bul li,.dc-hstats>div,.dc-pstats>div,.dc-scene,.dc-sector .dc-lead,.dc-form,.dc-legal article';
const COUNT = '.dc-hstats b,.dc-big,.dc-num>b,.dc-pstats b';

function countUp(el: HTMLElement) {
  if (el.dataset.done) return;
  el.dataset.done = '1';
  const t = (el.textContent || '').trim();
  const m = t.match(/^([+\-]?)([\d][\d,\.]*)(.*)$/);
  if (!m) return;
  const target = parseFloat(m[2].replace(/,/g, ''));
  if (!isFinite(target)) return;
  const comma = m[2].includes(',');
  const dec = (m[2].split('.')[1] || '').length;
  const t0 = performance.now(), dur = 1400;
  const step = (now: number) => {
    const p = Math.min(1, (now - t0) / dur), e = 1 - Math.pow(1 - p, 3);
    let v = (target * e).toFixed(dec);
    if (comma) v = Number(v).toLocaleString('en-US', { minimumFractionDigits: dec, maximumFractionDigits: dec });
    el.textContent = m[1] + v + m[3];
    if (p < 1) requestAnimationFrame(step); else el.textContent = t;
  };
  requestAnimationFrame(step);
}

export function useMotion(route: string) {
  useEffect(() => {
    const reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const nodes = Array.from(document.querySelectorAll<HTMLElement>(REVEAL));
    const counts = Array.from(document.querySelectorAll<HTMLElement>(COUNT));
    if (reduce || !('IntersectionObserver' in window)) { nodes.forEach((n) => n.classList.add('in')); return; }
    const io = new IntersectionObserver((es) => es.forEach((e) => {
      if (e.isIntersecting) { (e.target as HTMLElement).classList.add('in'); io.unobserve(e.target); }
    }), { threshold: 0.12, rootMargin: '0px 0px -6% 0px' });
    nodes.forEach((n) => {
      n.classList.add('rv');
      const sib = n.parentElement ? Array.from(n.parentElement.children).indexOf(n) : 0;
      n.style.transitionDelay = Math.min(sib, 6) * 70 + 'ms';
      io.observe(n);
    });
    const io2 = new IntersectionObserver((es) => es.forEach((e) => {
      if (e.isIntersecting) { countUp(e.target as HTMLElement); io2.unobserve(e.target); }
    }), { threshold: 0.4 });
    counts.forEach((c) => io2.observe(c));
    return () => { io.disconnect(); io2.disconnect(); };
  }, [route]);

  // pointer-follow tilt for cards
  useEffect(() => {
    const fine = window.matchMedia && window.matchMedia('(hover:hover)').matches;
    if (!fine) return;
    const move = (e: MouseEvent) => {
      const c = (e.target as HTMLElement).closest?.('.dc-card,.dc-why,.dc-num') as HTMLElement | null;
      if (!c) return;
      const r = c.getBoundingClientRect();
      c.style.setProperty('--rx', ((e.clientY - r.top) / r.height - 0.5) * -5 + 'deg');
      c.style.setProperty('--ry', ((e.clientX - r.left) / r.width - 0.5) * 6 + 'deg');
    };
    const leave = (e: MouseEvent) => {
      const c = (e.target as HTMLElement).closest?.('.dc-card,.dc-why,.dc-num') as HTMLElement | null;
      if (c) { c.style.setProperty('--rx', '0deg'); c.style.setProperty('--ry', '0deg'); }
    };
    document.addEventListener('mousemove', move);
    document.addEventListener('mouseout', leave);
    return () => { document.removeEventListener('mousemove', move); document.removeEventListener('mouseout', leave); };
  }, []);
}

/* Fleet: van driving along a road with spinning wheels, moving skyline, live badges */
export function RoadScene({ caption }: { caption?: string }) {
  return (
    <div className="dc-scene dc-road" role="img" aria-label="مركبة DashCord تتحرك على الطريق">
      <div className="dc-sky"><i /><i /><i /></div>
      <div className="dc-city"><svg viewBox="0 0 1200 120" preserveAspectRatio="none" aria-hidden="true"><path d="M0 120V70h60V40h50v30h40V55h70v65h50V30h60v90h70V60h60v60h50V45h80v75h60V65h70v55h60V35h50v85h80V70h60v50h70V50h60v70h60V75h40v45z" fill="#dfe8fb" /></svg><svg viewBox="0 0 1200 120" preserveAspectRatio="none" aria-hidden="true"><path d="M0 120V70h60V40h50v30h40V55h70v65h50V30h60v90h70V60h60v60h50V45h80v75h60V65h70v55h60V35h50v85h80V70h60v50h70V50h60v70h60V75h40v45z" fill="#dfe8fb" /></svg></div>
      <div className="dc-van">
        <span className="dc-pin p1">تأمين ساري</span>
        <span className="dc-pin p2">صيانة بعد 2,500 كم</span>
        <svg viewBox="0 0 220 110" aria-hidden="true">
          <g className="dc-van-body">
            <rect x="8" y="22" width="122" height="58" rx="9" fill="#1347d8" />
            <rect x="8" y="22" width="122" height="14" rx="7" fill="#0b1b3f" opacity=".16" />
            <path d="M130 38h38a10 10 0 018 4l20 20a10 10 0 012.800 7V80H130z" fill="#0b1b3f" />
            <path d="M138 44h28l17 17h-45z" fill="#cfe0ff" />
            <rect x="22" y="40" width="70" height="22" rx="5" fill="#fff" opacity=".95" />
            <text x="57" y="56" textAnchor="middle" fontSize="13" fontWeight="800" fill="#1347d8" fontFamily="IBM Plex Sans Arabic, sans-serif">DashCord</text>
            <rect x="196" y="62" width="9" height="7" rx="2" fill="#ffd24d" />
            <rect x="8" y="76" width="190" height="8" rx="3" fill="#061232" />
          </g>
          <g className="dc-wheel" style={{ transformOrigin: '52px 86px' }}><circle cx="52" cy="86" r="16" fill="#0b1b3f" /><circle cx="52" cy="86" r="7" fill="#dfe8fb" /><path d="M52 72v28M38 86h28" stroke="#6b7fb5" strokeWidth="3" /></g>
          <g className="dc-wheel" style={{ transformOrigin: '160px 86px' }}><circle cx="160" cy="86" r="16" fill="#0b1b3f" /><circle cx="160" cy="86" r="7" fill="#dfe8fb" /><path d="M160 72v28M146 86h28" stroke="#6b7fb5" strokeWidth="3" /></g>
        </svg>
      </div>
      <div className="dc-ground"><b /></div>
      {caption && <p className="dc-cap">{caption}</p>}
    </div>
  );
}

/* Reports: bars growing + line drawing */
export function BarsScene() {
  const h = [38, 52, 44, 66, 58, 80, 72, 92];
  return (
    <div className="dc-scene dc-bars" role="img" aria-label="رسم بياني متحرك">
      <svg viewBox="0 0 400 180" aria-hidden="true">
        {[40, 80, 120, 160].map((y) => <line key={y} x1="10" x2="390" y1={y} y2={y} stroke="#e6ebf5" />)}
        {h.map((v, i) => <rect key={i} className="dc-bar" style={{ animationDelay: i * 120 + 'ms' }} x={22 + i * 46} y={170 - v * 1.5} width="26" height={v * 1.5} rx="6" fill="#1347d8" opacity={0.35 + i * 0.09} />)}
        <path className="dc-line" d="M35 120 L81 105 L127 112 L173 85 L219 94 L265 62 L311 72 L357 38" fill="none" stroke="#16a34a" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
        <circle className="dc-dot" cx="357" cy="38" r="7" fill="#16a34a" />
      </svg>
      <span className="dc-pin p3">+12.5% إيرادات</span>
    </div>
  );
}

/* Settlements: coins rising into a wallet */
export function CoinsScene() {
  return (
    <div className="dc-scene dc-coins" role="img" aria-label="تسويات مالية متحركة">
      <div className="dc-wallet"><svg viewBox="0 0 24 24" width="64" height="64" fill="none" stroke="#fff" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M4 7.500A2.500 2.500 0 016.500 5H18v3M4 7.500V17a2 2 0 002 2h13a1 1 0 001-1v-9a1 1 0 00-1-1H6.500A2.500 2.500 0 014 7.500zM16 13.500h.01" /></svg></div>
      {[0, 1, 2, 3, 4].map((i) => <span key={i} className="dc-coin" style={{ left: 14 + i * 17 + '%', animationDelay: i * 0.5 + 's' }}>﷼</span>)}
      <span className="dc-pin p4">تسوية #1024 مدفوعة</span>
    </div>
  );
}

/* Operations: attendance ring */
export function RingScene() {
  const [v, setV] = useState(0);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = ref.current; if (!el) return;
    const io = new IntersectionObserver(([e]) => { if (e.isIntersecting) { setV(83); io.disconnect(); } }, { threshold: 0.3 });
    io.observe(el); return () => io.disconnect();
  }, []);
  const C = 2 * Math.PI * 52;
  return (
    <div ref={ref} className="dc-scene dc-ring" role="img" aria-label="نسبة الحضور">
      <svg viewBox="0 0 140 140" aria-hidden="true"><circle cx="70" cy="70" r="52" fill="none" stroke="#e6ebf5" strokeWidth="14" /><circle cx="70" cy="70" r="52" fill="none" stroke="#1347d8" strokeWidth="14" strokeLinecap="round" strokeDasharray={C} strokeDashoffset={C * (1 - v / 100)} transform="rotate(-90 70 70)" style={{ transition: 'stroke-dashoffset 1.6s cubic-bezier(.2,.8,.2,1)' }} /></svg>
      <div className="dc-ring-t"><b>{v}%</b><span>حضور اليوم</span></div>
      <span className="dc-pin p5">298 حاضر</span><span className="dc-pin p6">17% غياب</span>
    </div>
  );
}
