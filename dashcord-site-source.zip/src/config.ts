// WhatsApp number in international format, digits only (no +). Empty = widget hidden.
export const WA_NUMBER = '966504143736';
export const WA_TEXT = 'مرحبًا DashCord، أرغب في معرفة المزيد عن المنصة';
// Public contact phone shown in the footer. Empty = row hidden.
export const CONTACT_PHONE = '';
