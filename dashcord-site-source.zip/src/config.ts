// WhatsApp number in international format, digits only (no +). Empty = widget hidden.
export const WA_NUMBER = '966504143736';
export const WA_TEXT = 'مرحبًا DashCord، أرغب في معرفة المزيد عن المنصة';
// Public contact phone shown in the footer. Empty = row hidden.
export const CONTACT_PHONE = '';
// Mobile app store links. Leave empty until the apps are live: the site shows "قريبًا".
// When a link is set, its badge becomes a real link and a QR code for that link appears automatically.
export const ANDROID_URL = 'https://play.google.com/store/apps/details?id=com.dashcord.attendancehr';
export const IOS_URL = '';
