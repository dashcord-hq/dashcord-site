import React, { useState } from 'react';
import * as D from './data';
import { Ico, Head, Strip, Items, Stats, SocialIcon, nav, secImgs, img, Hero, FleetSec, OpsSec, FinSec, AnaSec, SupSec, ScreensSec, SectorsSec, NumbersSec, WhySec, CtaSec } from './sections';
import { DemoForm } from './DemoForm';
import { legal } from './legal';
import { RoadScene, BarsScene, CoinsScene, RingScene } from './motion';
import { WA_NUMBER } from './config';

const Bullets = ({ items }: { items: string[] }) => <ul className="dc-bul">{items.map((x) => <li key={x}>{x}</li>)}</ul>;
const Block = ({ title, sub, children, tint }: { title: string; sub?: string; children: React.ReactNode; tint?: boolean }) => (
  <section className={'dc-sec' + (tint ? ' dc-tint' : '')}>
    <div className="dc-blk-h"><h3>{title}</h3>{sub && <p>{sub}</p>}</div>
    {children}
  </section>
);
const Goto = ({ to, children }: { to: string; children: React.ReactNode }) => <a className="dc-btn dc-btn-ghost" href={'#/' + to}>{children}</a>;
const Cta = ({ title = 'جاهز لتجربة DashCord؟', text = 'تجربة مجانية بدون بطاقة بنكية، ودعم كامل أثناء التجربة.' }: { title?: string; text?: string }) => (
  <section className="dc-sec">
    <div className="dc-ctabar"><div><h3>{title}</h3><p>{text}</p></div>
      <div className="dc-row"><button type="button" className="dc-btn dc-btn-primary dc-lg" onClick={() => nav('demo')}>احجز عرضًا تجريبيًا ←</button><Goto to="contact">تواصل معنا</Goto></div></div>
  </section>
);
const PageHead = ({ badge, a, hl, b, sub }: { badge: string; a?: string; hl: string; b?: string; sub: string }) => (
  <section className="dc-sec dc-phead"><Head badge={badge} a={a} hl={hl} b={b} sub={sub} /></section>
);

// ---------- Home ----------
const modules: [string, string, string, string, string][] = [
  ['🚗', 'إدارة المركبات والأساطيل', 'ملف مركبة متكامل، تفاويض، استلام وتسليم، صيانة وتأمين وسجل كامل لكل مركبة.', 'vehicles', 'fleet'],
  ['👥', 'إدارة التشغيل', 'ملفات الموظفين والمناديب، الحضور والانصراف، الشيفتات والجداول وتقييم الأداء.', 'operations', 'ops'],
  ['💳', 'التسويات المالية', 'الكاش والتحصيلات، الخصومات والحوافز، العمولات والبونص وتسويات يومية وأسبوعية وشهرية.', 'settlements', 'fin'],
  ['📊', 'التقارير التحليلية', 'لوحات تحكم وتقارير تشغيلية ومالية وموارد بشرية ومركبات، مع تصدير PDF وExcel وCSV.', 'reports', 'ana'],
];
const ModuleCards = () => (
  <div className="dc-cards4 dc-mods">{modules.map(([i, t, d, to, im]) => (
    <article key={to} className="dc-why"><div className="dc-card-img"><img src={img[im]} alt={t} /><Ico c={i} /></div><h4>{t}</h4><p>{d}</p><a className="dc-more" href={'#/' + to}>← تفاصيل الوحدة</a></article>
  ))}</div>
);
export const Home = () => (
  <>
    <Hero />
    <section className="dc-sec">
      <Head badge="كل ما تحتاجه في منصة واحدة" a="أربع وحدات" hl="تعمل معًا" sub="تم تصميم DashCord لتجميع جميع العمليات اليومية داخل نظام موحد يساعدك على تقليل الوقت والجهد: إدارة المركبات والموظفين والتشغيل والتسويات والتقارير من مكان واحد." />
      <ModuleCards />
    </section>
    <SectorsSec />
    <NumbersSec />
    <WhySec />
    <CtaSec />
  </>
);

// ---------- Features ----------
export const Features = () => (
  <>
    <PageHead badge="المميزات" a="كل ما تحتاجه في" hl="منصة واحدة" sub="تم تصميم DashCord لتجميع جميع العمليات اليومية داخل نظام موحد يساعدك على تقليل الوقت والجهد. إدارة المركبات والموظفين والتشغيل والتسويات والتقارير من مكان واحد." />
    <section className="dc-sec"><ModuleCards /></section>
    <Block title="التنبيهات والإشعارات" sub="إشعارات فورية للمهام المهمة والمخالفات والتأخيرات، لمساعدتك على اتخاذ القرار في الوقت المناسب.">
      <Items items={[
        ['🔔', 'تنبيهات فورية للمشكلات والتأخيرات', 'تنبيهات لأي تأخر أو ضعف في أداء الموظفين والمناديب.'],
        ['🛡️', 'انتهاء التأمين والصيانة', 'تنبيهات قبل انتهاء التأمين والتفويضات ومواعيد الصيانة الدورية والفحص.'],
        ['👛', 'حدود الكاش', 'تنبيهات تلقائية عند تجاوز الحد المخصص للكاش مع المناديب.'],
        ['📋', 'متابعة الأحداث المهمة', 'شاشة مخصصة للتنبيهات والإشعارات لمتابعة كل ما يستحق انتباهك.'],
      ]} />
    </Block>
    <WhySec />
    <ScreensSec />
    <Block title="آمن وموثوق" sub="تجربة مرنة على جميع الأجهزة: يعمل النظام بسلاسة على الحاسوب والجوال والتابلت لإدارة عملياتك من أي مكان.">
      <Strip items={[...D.screenFeatures, ['☁️', 'نسخ احتياطي يومي', 'نسخ احتياطي تلقائي لجميع بياناتك'], ['🔐', 'صلاحيات متعددة', 'إدارة المستخدمين والأدوار والصلاحيات بسهولة.']]} />
    </Block>
    <Cta />
  </>
);

// ---------- Module pages ----------
const Related = ({ ids }: { ids: number[] }) => (
  <Block title="لمن تناسب هذه الوحدة؟" sub="القطاعات التي تعتمد على هذه الوحدة في عملها اليومي.">
    <div className="dc-cards5">{ids.map((n) => { const s = D.sectors[n]; return (
      <article key={s[1] as string} className="dc-card"><div className="dc-card-img"><img src={secImgs[n]} alt={s[1] as string} /><Ico c={s[0] as string} /></div><h4>{s[1] as string}</h4><p>{s[2] as string}</p><a className="dc-more" href="#/sectors">← كل القطاعات</a></article>
    ); })}</div>
  </Block>
);
const Others = ({ skip }: { skip: string }) => (
  <Block title="وحدات أخرى في DashCord" sub="كل وحدة تعمل مستقلة وتتكامل مع الباقي داخل نظام واحد.">
    <div className="dc-row">{modules.filter((m) => m[3] !== skip).map((m) => <Goto key={m[3]} to={m[3]}>{m[1]}</Goto>)}</div>
  </Block>
);

export const Vehicles = () => (
  <>
    <FleetSec />
    <section className="dc-sec"><RoadScene caption="مركباتك تحت المتابعة لحظة بلحظة" /></section>
    <Block title="تفاصيل ملف المركبة" sub="كل ما يخص مركباتك في نظام واحد متكامل: من البيانات الأساسية إلى سجل الحوادث والمخالفات." tint>
      <Bullets items={[
        'بيانات المركبة والوثائق والتأمين والعداد والحالة والصور في ملف واحد.',
        'إصدار التفاويض وإلغاؤها ومتابعة تواريخ الانتهاء، مع تنبيهات قبل انتهاء التفويض.',
        'نماذج استلام وتسليم إلكترونية موثقة مع صور وفحص شامل وقراءة العداد والوقود والملحقات.',
        'تنبيهات الصيانة الدورية والفحص وانتهاء التأمين.',
        'سجل كامل للحوادث والمخالفات والصيانة ونقل الملكية وتجديد الاستمارة.',
        'متابعة عقود إيجار المركبات والتفاويض عبر رمز تحقق OTP.',
      ]} />
    </Block>
    <Related ids={[1, 2, 4]} />
    <Others skip="vehicles" />
    <Cta />
  </>
);
export const Operations = () => (
  <>
    <OpsSec />
    <section className="dc-sec"><RingScene /></section>
    <Block title="من الانضمام إلى تقييم الأداء" sub="متابعة شاملة للموظفين والمناديب منذ الانضمام وحتى تقييم الأداء." tint>
      <Bullets items={[
        'ملف موظف متكامل: البيانات الشخصية والمستندات وسجل العمل.',
        'الحضور والانصراف: إدارة الحضور والغياب والتأخير وساعات العمل والساعات الإضافية.',
        'الشيفتات والجداول: توزيع المهام وإدارة جداول العمل على الفرق.',
        'تقييم الأداء: مؤشرات الأداء والإنتاجية مع تنبيهات لأي تأخير أو ضعف.',
        'إدارة المهام والصلاحيات والموافقات داخل الشركة.',
      ]} />
    </Block>
    <Block title="تطبيق DashCord HR والموارد البشرية" sub="إدارة الحضور والرواتب من الجوال، بما يناسب متطلبات السوق السعودي.">
      <Items items={[
        ['📱', 'تطبيق جوال للموظفين', 'تطبيق DashCord HR متاح على متجر Google Play لإدارة الحضور والعمليات من أي مكان.'],
        ['🕒', 'حضور بالبصمة والموقع الجغرافي', 'تسجيل الحضور والانصراف بالبصمة والتحقق من الموقع الجغرافي.'],
        ['🧾', 'مسيرات رواتب', 'مسيرات رواتب متوافقة مع منصة مدد ونظام حماية الأجور.'],
        ['🛡️', 'نسب التأمينات', 'احتساب نسب التأمينات الاجتماعية (GOSI) وفق الأنظمة المعمول بها.'],
      ]} />
    </Block>
    <Related ids={[0, 3, 4]} />
    <Others skip="operations" />
    <Cta />
  </>
);
export const Settlements = () => (
  <>
    <FinSec />
    <section className="dc-sec"><CoinsScene /></section>
    <Block title="محفظة المندوب والتسويات" sub="إدارة دقيقة للتسويات المالية والمدفوعات والمستحقات." tint>
      <Bullets items={[
        'محفظة لكل مندوب تشمل السلف والغرامات والحوافز والقروض.',
        'تحديد حد أقصى للكاش مع المندوب وتنبيه تلقائي عند تجاوزه.',
        'متابعة المبالغ المستلمة والتحصيلات اليومية.',
        'تسويات يومية وأسبوعية وشهرية، مع إصدار التسويات بصيغة PDF.',
        'حساب العمولات والمكافآت والبونص تلقائيًا وفق السياسات المحددة.',
      ]} />
    </Block>
    <Block title="الربط مع تطبيقات التوصيل" sub="للشركات التي تعمل بمناديب على تطبيقات التوصيل.">
      <Items items={[
        ['🛵', 'تطبيقات التوصيل', 'ربط بيانات المناديب والطلبات مع تطبيقات التوصيل مثل جاهز وهنقرستيشن وكيتا.'],
        ['📍', 'تتبع مباشر', 'شاشة تتبع مباشر لمناديب هنقرستيشن في أي مدينة.'],
      ]} />
    </Block>
    <Related ids={[0]} />
    <Others skip="settlements" />
    <Cta />
  </>
);
export const Reports = () => (
  <>
    <AnaSec />
    <section className="dc-sec"><BarsScene /></section>
    <Block title="تقارير شاملة تغطي كل جوانب عملك" sub="تقارير ولوحات تحكم تساعدك على فهم أعمالك واتخاذ قرارات مبنية على بيانات دقيقة." tint>
      <Bullets items={[
        'لوحات تحكم تفاعلية: مؤشرات أداء لحظية ورسوم بيانية.',
        'تقارير تشغيلية: متابعة الإنجاز والإنتاجية والطلبات ومعدلات النجاح والإلغاء.',
        'تقارير مالية: الإيرادات والمصروفات والتسويات والكاش والعمولات والمكافآت والخصومات.',
        'تقارير الموارد البشرية: الحضور والغياب والشيفتات والإجازات وتقييم الأداء.',
        'تقارير المركبات: الصيانة والتأمين والمخالفات والحوادث والتفويضات.',
      ]} />
    </Block>
    <Block title="تصدير ومشاركة" sub="تصدير التقارير بصيغ PDF وExcel وCSV بسهولة، مع فلاتر ذكية وتقارير مخصصة."><div className="dc-row"><span className="dc-fmt">PDF</span><span className="dc-fmt">Excel</span><span className="dc-fmt">CSV</span></div></Block>
    <Others skip="reports" />
    <Cta />
  </>
);

// ---------- Sectors ----------
const liveSectorLists: string[][] = [
  ['متابعة الأداء والإنتاجية', 'إدارة الكاش والتحصيل', 'إدارة الشيفتات والحضور', 'التسويات المالية', 'التقارير التشغيلية'],
  ['إدارة الأسطول', 'متابعة الصيانة', 'مراقبة التشغيل', 'تقارير الأداء', 'إدارة المستندات'],
  ['ملف مركبة متكامل', 'إدارة التفاويض', 'متابعة التأمين', 'سجل المركبة الكامل', 'الاستلام والتسليم الإلكتروني'],
  ['إدارة الموظفين', 'إدارة الحضور والانصراف', 'إدارة المهام', 'التقارير الإدارية', 'الصلاحيات والموافقات'],
  ['إدارة المعدات', 'متابعة المركبات', 'إدارة العمالة', 'تقارير المشاريع', 'مراقبة التكاليف'],
];
export const Sectors = () => (
  <>
    <PageHead badge="مصمم لمختلف القطاعات" a="مصمم للشركات في" hl="مختلف القطاعات" sub="تم تطوير DashCord ليتوافق مع احتياجات العديد من القطاعات المختلفة مع إمكانية التخصيص حسب طبيعة العمل." />
    {D.sectors.map(([i, t, d, l], n) => (
      <section key={t as string} className={'dc-sec dc-sector' + (n % 2 ? ' dc-tint' : '')}>
        <div className={'dc-two' + (n % 2 ? ' dc-flip' : '')}>
          <div><h3><Ico c={i as string} /> {t as string}</h3><p className="dc-lead">{d as string}</p>
            <Bullets items={Array.from(new Set([...liveSectorLists[n], ...(l as string[])]))} /></div>
          <img className="dc-shot" src={secImgs[n]} alt={t as string} />
        </div>
      </section>
    ))}
    <section className="dc-sec"><p className="dc-note">سواء كنت شركة صغيرة أو مؤسسة كبيرة، DashCord يوفر لك الأدوات التي تحتاجها لإدارة عملياتك بكفاءة واحترافية.</p></section>
    <Cta />
  </>
);

// ---------- Pricing ----------
export const Pricing = () => (
  <>
    <PageHead badge="الأسعار" a="ابدأ بتجربة مجانية،" hl="ثم اختر ما يناسبك" sub="تجربة مجانية بدون بطاقة بنكية، وإعداد سريع، ودعم كامل أثناء التجربة. الأسعار تُحدد بحسب احتياج شركتك، وتحصل على عرض واضح من فريق المبيعات." />
    <Block title="التجربة المجانية">
      <Strip items={[
        ['💳', 'بدون بطاقة بنكية', 'ابدأ التجربة دون إدخال أي بيانات دفع.'],
        ['⚡', 'إعداد سريع', 'تجهيز حساب شركتك وتفعيله بسرعة.'],
        ['🎧', 'دعم كامل أثناء التجربة', 'فريق الدعم معك في كل خطوة.'],
        ['🎓', 'تدريب مجاني', 'جلسات تدريبية مجانية لفريقك.'],
        ['✅', 'إلغاء في أي وقت', 'بدون التزام.'],
      ]} />
    </Block>
    <Block title="ما الذي يشمله الاشتراك" sub="أربع وحدات متكاملة وأدوات مشتركة داخل نظام واحد." tint>
      <div className="dc-two">
        <div><h4>الوحدات</h4><Bullets items={['إدارة المركبات والأساطيل', 'إدارة التشغيل: الموظفون والمناديب والحضور والشيفتات', 'التسويات المالية', 'التقارير التحليلية']} /></div>
        <div><h4>مع كل اشتراك</h4><Bullets items={['صلاحيات مرنة لكل مستخدم', 'تطبيق جوال وتصميم متجاوب', 'نسخ احتياطي يومي', 'تحديثات مستمرة ومميزات جديدة', 'دعم فني وتذاكر ومركز معرفة', 'تدريب شامل لفريقك']} /></div>
      </div>
    </Block>
    <Block title="عرض سعر لشركتك" sub="لا توجد أسعار معلنة على الموقع حاليًا. أرسل لنا طلبك وسيصلك عرض من فريق المبيعات.">
      <Bullets items={['اذكر عدد الموظفين والمناديب وعدد المركبات.', 'حدد الوحدات التي تحتاجها.', 'يتواصل معك فريقنا لتحديد موعد العرض التجريبي والسعر.']} />
      <p className="dc-small">تخضع الاشتراكات للأسعار المعلنة، ولا تُسترد الرسوم عن الفترات المستخدمة، ويحق لـ DashCord تعديل الأسعار مستقبلاً مع إشعار العملاء. التفاصيل في <a href="#/terms">الشروط والأحكام</a>.</p>
    </Block>
    <Cta title="احصل على عرض سعر" text="احجز عرضًا تجريبيًا وسنحدد معك الباقة المناسبة." />
  </>
);

// ---------- About ----------
export const About = () => (
  <>
    <PageHead badge="من نحن" a="DashCord، شريكك في" hl="نجاح عملياتك" sub="منصة تشغيل متكاملة تساعد الشركات على إدارة المركبات والموظفين وعمليات التشغيل والتسويات والتقارير التحليلية من خلال نظام واحد ذكي وسهل الاستخدام." />
    <Block title="ماذا نقدم">
      <p className="dc-lead">DashCord ليست مجرد نظام، بل شريكك في نجاح عملياتك. نساعدك على التحكم الكامل، وتقليل التكاليف، وزيادة الإنتاجية، وتحقيق أهدافك بثقة. تعمل المنصة منذ أكثر من عام على التطور المستمر مع فريق تقني متخصص، وهي في توسع مستمر في المملكة العربية السعودية.</p>
      <ModuleCards />
    </Block>
    <Block title="نتائج مع عملائنا" sub="تحكم أفضل، خفض للتكاليف، وزيادة في الإنتاجية عبر منصة واحدة." tint>
      <div className="dc-pstats dc-pstats-l"><div><b>+98%</b><span>تحسن في الكفاءة</span></div><div><b>-40%</b><span>توفير في التكاليف</span></div><div><b>+60%</b><span>زيادة في الإنتاجية</span></div></div>
    </Block>
    <Block title="التزامنا">
      <Strip items={D.ctaStrip} />
    </Block>
    <WhySec />
    <Cta />
  </>
);

// ---------- Support ----------
export const Support = () => (
  <>
    <SupSec />
    <Block title="التزامات الدعم" sub="مواعيد الاستجابة المعتمدة في اتفاقية مستوى الخدمة." tint>
      <Bullets items={['تذاكر الأعطال الحرجة: خلال 4 ساعات عمل.', 'الأعطال المتوسطة: خلال يوم عمل.', 'الاستفسارات العامة: خلال يومي عمل.', 'الهدف التشغيلي السنوي لتوفر الخدمة: 99.5% على الأقل.']} />
      <p className="dc-small"><a href="#/sla">اقرأ اتفاقية مستوى الخدمة كاملة</a></p>
    </Block>
    <Block title="تواصل مع الدعم">
      <div className="dc-row"><a className="dc-btn dc-btn-primary" href="mailto:info@dash-cord.com">info@dash-cord.com</a><Goto to="faq">الأسئلة الشائعة</Goto><Goto to="contact">تواصل معنا</Goto></div>
    </Block>
  </>
);

// ---------- FAQ ----------
const faqs: [string, string][] = [
  ['ما هي DashCord؟', 'DashCord منصة تشغيل متكاملة تساعد الشركات على إدارة المركبات والموظفين وعمليات التشغيل والتسويات والتقارير التحليلية من خلال نظام واحد.'],
  ['لمن تناسب المنصة؟', 'صُممت لشركات التوصيل، والشركات اللوجستية، وشركات تأجير السيارات، والشركات والمؤسسات، وقطاع المقاولات والتشغيل، مع إمكانية التخصيص حسب طبيعة العمل. سواء كنت شركة صغيرة أو مؤسسة كبيرة.'],
  ['ما الوحدات التي تضمها المنصة؟', 'إدارة المركبات والأساطيل، وإدارة التشغيل (الموظفون والمناديب والحضور والشيفتات والأداء)، والتسويات المالية، والتقارير التحليلية، مع تنبيهات ذكية ودعم فني.'],
  ['هل توجد تجربة مجانية؟', 'نعم. تجربة مجانية بدون بطاقة بنكية، مع إعداد سريع ودعم كامل أثناء التجربة، ويمكنك الإلغاء في أي وقت.'],
  ['كيف أبدأ؟', 'من صفحة "احجز عرضًا تجريبيًا" سجّل بيانات شركتك، وسيتواصل معك فريق DashCord لتفعيل حساب شركتك وتحديد موعد العرض التجريبي.'],
  ['كم تبلغ الأسعار؟', 'لا توجد أسعار معلنة حاليًا. الأسعار تُحدد بحسب احتياج شركتك، ويصلك عرض من فريق المبيعات بعد طلب العرض التجريبي. تخضع الاشتراكات للأسعار المعلنة وللشروط والأحكام.'],
  ['كيف تدار تسويات المناديب؟', 'تدير المنصة الكاش والتحصيلات، والخصومات والغرامات والحوافز، والعمولات والبونص، وتصدر تسويات يومية وأسبوعية وشهرية. لكل مندوب محفظة تشمل السلف والغرامات والحوافز والقروض، مع حد أقصى للكاش وتنبيه عند تجاوزه.'],
  ['هل تدعم إدارة الرواتب والحضور؟', 'نعم. يدير النظام الحضور والانصراف والشيفتات، ويوفر تطبيق DashCord HR على Google Play مع حضور بالبصمة والموقع الجغرافي ومسيرات رواتب متوافقة مع مدد وحماية الأجور واحتساب نسب التأمينات.'],
  ['هل تدعم إدارة المركبات والتفويضات؟', 'نعم. لكل مركبة ملف متكامل يضم الوثائق والتأمين والصيانة والعداد، مع إصدار التفاويض وإلغائها ومتابعة انتهائها، واستلام وتسليم إلكتروني موثق بالصور وسجل كامل للحوادث والمخالفات.'],
  ['هل أستطيع تصدير التقارير؟', 'نعم، بصيغ PDF وExcel وCSV، مع فلاتر ذكية وتقارير مخصصة.'],
  ['هل يعمل النظام على الجوال؟', 'نعم. يعمل بسلاسة على الحاسوب والجوال والتابلت بتصميم متجاوب، وتتوفر تطبيقات جوال لإدارة العمليات من أي مكان.'],
  ['كيف تُدار الصلاحيات؟', 'يمكنك إدارة المستخدمين والأدوار وتحديد صلاحيات الوصول لكل مستخدم بدقة حسب المسؤوليات داخل النظام.'],
  ['ما مدى أمان بياناتي؟', 'نلتزم بحماية البيانات من الوصول غير المصرح به والتعديل أو الحذف غير المشروع وفقدان البيانات، مع نسخ احتياطي يومي. ولا نبيع بيانات العملاء ولا نؤجرها لأي طرف ثالث. التفاصيل في سياسة الخصوصية.'],
  ['ما مستوى الخدمة والدعم؟', 'الهدف التشغيلي السنوي لتوفر الخدمة 99.5% على الأقل. تُعالج تذاكر الأعطال الحرجة خلال 4 ساعات عمل، والمتوسطة خلال يوم عمل، والاستفسارات العامة خلال يومي عمل.'],
  ['هل يوجد تدريب؟', 'نعم، تُقدَّم جلسات تدريبية مجانية لفريقك.'],
  ['كيف أحذف حسابي؟', 'يتم ذلك عبر طلب حذف الحساب بعد التحقق من الملكية. الحذف نهائي، وقد تحتفظ DashCord ببعض السجلات إذا كان ذلك مطلوبًا بموجب الأنظمة. التفاصيل في صفحة حذف الحساب.'],
];
export const Faq = () => {
  const [open, setOpen] = useState(0);
  return (
    <>
      <PageHead badge="الأسئلة الشائعة" a="إجابات سريعة لأكثر" hl="الاستفسارات شيوعًا" sub="لم تجد إجابة سؤالك؟ تواصل معنا وسنرد عليك." />
      <section className="dc-sec"><div className="dc-faq">{faqs.map(([q, a], i) => (
        <div key={q} className={'dc-faq-i' + (open === i ? ' on' : '')}>
          <button type="button" aria-expanded={open === i} onClick={() => setOpen(open === i ? -1 : i)}><span>{q}</span><i aria-hidden="true">{open === i ? '−' : '+'}</i></button>
          {open === i && <p>{a}</p>}
        </div>
      ))}</div></section>
      <Cta title="عندك سؤال آخر؟" text="فريقنا جاهز للرد عليك." />
    </>
  );
};

// ---------- Contact ----------
export const Contact = () => (
  <>
    <PageHead badge="تواصل معنا" a="تحدث مع" hl="فريق المبيعات" sub="يسعدنا الرد على استفساراتك وترتيب عرض تجريبي لشركتك." />
    <section className="dc-sec">
      <div className="dc-cards4">
        <article className="dc-why"><Ico c="💬" /><h4>البريد الإلكتروني</h4><p>للمبيعات والدعم والاستفسارات.</p><a className="dc-more" href="mailto:info@dash-cord.com">info@dash-cord.com</a></article>
        <article className="dc-why"><Ico c="📱" /><h4>واتساب</h4><p>راسلنا مباشرة على واتساب.</p><a className="dc-more" href={'https://wa.me/' + WA_NUMBER} target="_blank" rel="noopener noreferrer">ابدأ المحادثة</a></article>
        <article className="dc-why"><Ico c="🏢" /><h4>الموقع والمقر</h4><p>www.dash-cord.com<br />المملكة العربية السعودية</p></article>
        <article className="dc-why"><Ico c="📝" /><h4>عرض تجريبي</h4><p>سجّل شركتك وسنتواصل معك لتفعيل الحساب.</p><a className="dc-more" href="#/demo">احجز عرضًا تجريبيًا</a></article>
      </div>
    </section>
    <Block title="تابعنا على" tint>
      <div className="dc-soc dc-soc-l"><div>{D.socials.map(([n, u, k]) => <a key={k} href={u} target="_blank" rel="noopener noreferrer" aria-label={n} title={n}><SocialIcon k={k} /></a>)}</div></div>
    </Block>
  </>
);

export const Demo = () => (
  <>
    <PageHead badge="عرض تجريبي" a="احجز عرضًا" hl="تجريبيًا" sub="تجربة مجانية - بدون بطاقة بنكية. سجّل بيانات شركتك وسيتواصل معك فريقنا لتفعيل الحساب." />
    <DemoForm />
  </>
);

// ---------- Legal ----------
const legalMeta: Record<string, string> = { privacy: 'سياسة الخصوصية', terms: 'الشروط والأحكام', 'acceptable-use': 'سياسة الاستخدام المقبول', sla: 'اتفاقية مستوى الخدمة (SLA)', cookies: 'سياسة ملفات الارتباط', 'delete-account': 'حذف الحساب' };
export const legalLinks = Object.entries(legalMeta);
export const Legal = ({ slug }: { slug: string }) => {
  const blocks = legal[slug] || [];
  return (
    <section className="dc-sec dc-legal">
      <div className="dc-legal-nav">{legalLinks.map(([k, t]) => <a key={k} href={'#/' + k} className={k === slug ? 'on' : ''}>{t}</a>)}</div>
      <article>
        {blocks.map(([t, v], i) => t === 'h1' ? <h1 key={i}>{v as string}</h1> : t === 'h2' ? <h2 key={i}>{v as string}</h2> : t === 'p' ? <p key={i}>{v as string}</p> : t === 'ol' ? <ol key={i}>{(v as string[]).map((x) => <li key={x}>{x}</li>)}</ol> : <ul key={i}>{(v as string[]).map((x) => <li key={x}>{x}</li>)}</ul>)}
        {slug !== 'delete-account' && <p className="dc-upd">آخر تحديث: 27 يوليو 2026</p>}
        {slug === 'delete-account' && <a className="dc-btn dc-btn-ghost" href="mailto:info@dash-cord.com?subject=%D8%B7%D9%84%D8%A8%20%D8%AD%D8%B0%D9%81%20%D8%AD%D8%B3%D8%A7%D8%A8">إرسال طلب حذف الحساب</a>}
      </article>
    </section>
  );
};
