import React, { useState } from 'react';

// Set this to the URL that receives signups (POST, JSON). While empty, the page validates the form
// but does not send anything, and says so.
export const SIGNUP_ENDPOINT = '';

const sectors = ['شركات التوصيل', 'الشركات اللوجستية', 'شركات تأجير السيارات', 'الشركات والمؤسسات', 'المقاولات والتشغيل', 'أخرى'];
const sizes = ['أقل من 10', '10 - 50', '51 - 200', '201 - 1000', 'أكثر من 1000'];
type F = { company: string; name: string; phone: string; email: string; sector: string; size: string; notes: string };
const empty: F = { company: '', name: '', phone: '', email: '', sector: '', size: '', notes: '' };

export function DemoForm() {
  const [f, setF] = useState<F>(empty);
  const [err, setErr] = useState<Partial<Record<keyof F, string>>>({});
  const [state, setState] = useState<'idle' | 'sending' | 'sent' | 'error' | 'unwired'>('idle');
  const set = (k: keyof F) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => setF({ ...f, [k]: e.target.value });

  const submit = async () => {
    const e: Partial<Record<keyof F, string>> = {};
    if (!f.company.trim()) e.company = 'اسم الشركة مطلوب';
    if (!f.name.trim()) e.name = 'اسم المسؤول مطلوب';
    if (!/^[+\d][\d\s-]{7,}$/.test(f.phone.trim())) e.phone = 'أدخل رقم جوال صحيح';
    if (!/^\S+@\S+\.\S+$/.test(f.email.trim())) e.email = 'أدخل بريدًا إلكترونيًا صحيحًا';
    if (!f.sector) e.sector = 'اختر القطاع';
    setErr(e);
    if (Object.keys(e).length) return;
    if (!SIGNUP_ENDPOINT) { setState('unwired'); return; }
    setState('sending');
    try {
      const r = await fetch(SIGNUP_ENDPOINT, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ...f, status: 'pending', source: 'dash-cord.com', at: new Date().toISOString() }) });
      if (!r.ok) throw new Error(String(r.status));
      setState('sent');
    } catch { setState('error'); }
  };

  if (state === 'sent') return (
    <section className="dc-sec" id="dc-demo"><div className="dc-form dc-form-done"><h2>تم استلام طلبك ✓</h2><p>شكرًا لك. سيتواصل معك فريق DashCord قريبًا لتفعيل حساب شركتك وتحديد موعد العرض التجريبي.</p></div></section>
  );
  const field = (k: keyof F, label: string, input: React.ReactNode) => (
    <label className={'dc-fld' + (err[k] ? ' bad' : '')}><span>{label}</span>{input}{err[k] && <small>{err[k]}</small>}</label>
  );
  return (
    <section className="dc-sec" id="dc-demo">
      <div className="dc-form">
        <div className="dc-head" style={{ marginBottom: 20 }}>
          <span className="dc-badge">سجّل شركتك</span>
          <h2>احجز <em>عرضك التجريبي</em></h2>
          <p>املأ بيانات شركتك وسيقوم فريقنا بتفعيل حسابك والتواصل معك خلال وقت قصير.</p>
        </div>
        <div className="dc-fgrid">
          {field('company', 'اسم الشركة *', <input value={f.company} onChange={set('company')} autoComplete="organization" />)}
          {field('name', 'اسم المسؤول *', <input value={f.name} onChange={set('name')} autoComplete="name" />)}
          {field('phone', 'رقم الجوال *', <input value={f.phone} onChange={set('phone')} inputMode="tel" autoComplete="tel" dir="ltr" placeholder="+966 5X XXX XXXX" />)}
          {field('email', 'البريد الإلكتروني *', <input value={f.email} onChange={set('email')} inputMode="email" autoComplete="email" dir="ltr" placeholder="name@company.com" />)}
          {field('sector', 'القطاع *', <select value={f.sector} onChange={set('sector')}><option value="">اختر</option>{sectors.map((x) => <option key={x}>{x}</option>)}</select>)}
          {field('size', 'عدد المناديب / الموظفين', <select value={f.size} onChange={set('size')}><option value="">اختر</option>{sizes.map((x) => <option key={x}>{x}</option>)}</select>)}
        </div>
        {field('notes', 'ملاحظات (اختياري)', <textarea rows={3} value={f.notes} onChange={set('notes')} />)}
        <button type="button" className="dc-btn dc-btn-primary dc-lg" disabled={state === 'sending'} onClick={() => { void submit(); }}>{state === 'sending' ? 'جاري الإرسال...' : 'سجّل شركتي ←'}</button>
        {state === 'error' && <p className="dc-fmsg bad" role="status">تعذر إرسال الطلب. حاول مرة أخرى أو راسلنا على info@dash-cord.com</p>}
        {state === 'unwired' && <p className="dc-fmsg bad" role="status">نسخة معاينة: البيانات سليمة لكن لم يتم إرسالها، لأن استلام الطلبات لم يُربط بعد.</p>}
      </div>
    </section>
  );
}
